# DDOS-LAYER-L4-L7
# PaltalkDDOS ![](https://img.shields.io/badge/Version-3.6-brightgreen.svg) ![](https://img.shields.io/badge/license-GPLv2-blue.svg)
 A script for using proxies to attack http(s) server. and L4

# Donate Bitcon : 19oTxQe8CKsC6SGTD4gN9kPgTWzUUSFQ7y

 
 News:
- [x] Added Output Indicator
- [x] Added Url Parser

 Info:
- [x] Using Python2

## Showcase
![](https://i0.wp.com/s1.uphinh.org/2020/12/29/asdasdasdasdasd.png)
![](https://i0.wp.com/s1.uphinh.org/2020/12/29/tttttttt.png)

## Install

    python -m pip install --upgrade pip pysocks request bs4 requests js2py cfscrape beautifulsoup4 colorama wget scapy PySocks
    git clone https://github.com/PaltalkDDOS/DDOS-LAYER-L4-L7
    cd DDOS-LAYER-L4-L7

## Usage

    python PaltalkDDOS.py

